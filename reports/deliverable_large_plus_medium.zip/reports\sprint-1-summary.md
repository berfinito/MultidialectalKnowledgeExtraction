# Sprint-1 Summary

## whisperct2_kmr_test_DEC-none_FL-auto_beam1_vad0_translit-none
- variant: DEC-none_FL-auto_beam1_vad0_translit-none
- jsonl: data\interim\asr_post\whisperct2_kmr_test_DEC-none_FL-auto_beam1_vad0_translit-none.jsonl
- report: reports\asr_whisperct2_kmr_test_DEC-none_FL-auto_beam1_vad0_translit-none.json
- items: 3991, avg_prob: 1.0
- detected_language (top): tr:3991
- metrics: WER=1.0162147050601062 CER=0.481737816861787 RTF=0.09819678136768413

## whisperct2_tr_validation_DEC-none_FL-auto_beam1_vad0_translit-none
- variant: DEC-none_FL-auto_beam1_vad0_translit-none
- jsonl: data\interim\asr_post\whisperct2_tr_validation_DEC-none_FL-auto_beam1_vad0_translit-none.jsonl
- report: reports\asr_whisperct2_tr_validation_DEC-none_FL-auto_beam1_vad0_translit-none.json
- items: 71047, avg_prob: 1.0
- detected_language (top): tr:71047
- metrics: WER=0.3273675687640528 CER=0.10421475319062051 RTF=0.06267937218909415

## whisperct2_zza_validation_DEC-none_FL-auto_beam1_vad0_translit-none
- variant: DEC-none_FL-auto_beam1_vad0_translit-none
- jsonl: data\interim\asr_post\whisperct2_zza_validation_DEC-none_FL-auto_beam1_vad0_translit-none.jsonl
- report: reports\asr_whisperct2_zza_validation_DEC-none_FL-auto_beam1_vad0_translit-none.json
- items: 1589, avg_prob: 1.0
- detected_language (top): tr:1589
- metrics: WER=0.9673565773024031 CER=0.45575583199345576 RTF=0.11537560729038465

## Best baseline
- run: whisperct2_tr_validation_DEC-none_FL-auto_beam1_vad0_translit-none
- score: 0.3273675687640528
