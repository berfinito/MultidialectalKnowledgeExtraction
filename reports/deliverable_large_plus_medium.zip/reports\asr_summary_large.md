# ASR Summary (medium)

Generated: 2025-09-08T18:43:31

| lang | split | model | n | WER | CER | RTF | report |
|---|---|---|---:|---:|---:|---:|---|
| kmr | test | openai/whisper-large-v2 | 3991 | 2.233 | 1.679 | 0.081 | reports\asr_whisper_kmr_test_large.json |
| kmr | validation | openai/whisper-large-v2 | 61612 | 2.233 | 1.697 | 0.091 | reports\asr_whisper_kmr_validation_large.json |
| tr | test | openai/whisper-large-v2 | 8391 | 0.593 | 0.508 | 0.095 | reports\asr_whisper_tr_test_large.json |
| tr | validation | openai/whisper-large-v2 | 71047 | 0.749 | 0.655 | 0.103 | reports\asr_whisper_tr_validation_large.json |
| zza | test | openai/whisper-large-v2 | 392 | 2.450 | 1.814 | 0.073 | reports\asr_whisper_zza_test_large.json |
| zza | validation | openai/whisper-large-v2 | 1589 | 2.650 | 2.127 | 0.115 | reports\asr_whisper_zza_validation_large.json |
