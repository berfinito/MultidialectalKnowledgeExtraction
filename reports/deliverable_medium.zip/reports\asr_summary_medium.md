# ASR Summary (medium)

Generated: 2025-09-08T00:58:13

| lang | split | model | n | WER | CER | RTF | report |
|---|---|---|---:|---:|---:|---:|---|
| kmr | test | openai/whisper-medium | 3991 | 3.486 | 2.453 | 0.079 | reports\asr_whisper_kmr_test_medium.json |
| kmr | validation | openai/whisper-medium | 61612 | 3.304 | 2.391 | 0.136 | reports\asr_whisper_kmr_validation_medium.json |
| tr | test | openai/whisper-medium | 8391 | 0.667 | 0.422 | 0.052 | reports\asr_whisper_tr_test_medium.json |
| tr | validation | openai/whisper-medium | 71047 | 0.772 | 0.506 | 0.068 | reports\asr_whisper_tr_validation_medium.json |
| zza | test | openai/whisper-medium | 392 | 3.921 | 2.911 | 0.081 | reports\asr_whisper_zza_test_medium.json |
| zza | validation | openai/whisper-medium | 1589 | 3.837 | 2.941 | 0.089 | reports\asr_whisper_zza_validation_medium.json |
