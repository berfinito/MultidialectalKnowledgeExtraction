# ASR Summary (medium)

Generated: 2025-09-08T01:48:41

| lang | split | model | n | WER | CER | RTF | report |
|---|---|---|---:|---:|---:|---:|---|
| kmr | validation | openai/whisper-large-v2 | 512 | 2.475 | 1.804 | 0.078 | reports\asr_whisper_kmr_validation_large.json |
| tr | validation | openai/whisper-large-v2 | 512 | 0.596 | 0.493 | 0.075 | reports\asr_whisper_tr_validation_large.json |
| zza | validation | openai/whisper-large-v2 | 512 | 2.390 | 1.803 | 0.081 | reports\asr_whisper_zza_validation_large.json |
